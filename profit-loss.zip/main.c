#include<stdio.h>
void main()
{
    float cp,sp,profit,loss;
    float pr,ls,prper,lsper;
    printf("enter cost price and selling price");
    scanf("%f%f",&cp,&sp);
    if(cp<sp)
    {
        profit=sp-cp;
        prper=((profit*100)/cp);
        printf("profit percentage=%f\n",prper);
    }
    else if(cp>sp)
    {
        loss=cp-sp;
        lsper=((loss*100)/cp);
        printf("loss percentage=%f",lsper);
    }
    else
    {
        printf("no profit no loss");
    }
}